//@Override
package NO_2;

public class Food_2 {
        String name;
        Food_2(String name){
            this.name = name;
        }
        void bought(){
            System.out.println(this.name + " telah dibeli oleh pelanggan");
        }
    
}
