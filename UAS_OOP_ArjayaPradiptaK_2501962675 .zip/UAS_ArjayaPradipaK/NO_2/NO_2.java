package NO_2;

public class NO_2 {
    
    public static void main(String[] args) {
        
        Food_2 Donat = new Food_2("Donat");
        Food_2 Kerupuk = new Food_2("Kerupuk");
        Food_2 Kue = new Food_2("Kue");
        Food_2 Nastar = new Food_2("Nastar");
        Food_2 Permen = new Food_2("Permen");
        Food_2 Pretzel = new Food_2("Pretzel");
        Food_2 Toast = new Food_2("Toast Egg");
        Food_2 Beef = new Food_2("Beef Burger");
        Food_2 Burger = new Food_2("Burger");

        Food_2[] foods2 = {Donat, Kerupuk, Kue, Nastar, Permen, Pretzel, Toast, Beef, Burger};
        
        for (Food_2 Food_2 : foods2){
            Food_2.bought();
        }
    }
}
